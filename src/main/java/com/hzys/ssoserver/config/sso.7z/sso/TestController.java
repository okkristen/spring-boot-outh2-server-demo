package com.hzys.ssoserver.config.sso;


public class TestController {
}
