package com.hzys.ssoserver.config.sso;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Qualifier;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.data.redis.connection.RedisConnectionFactory;
import org.springframework.security.authentication.AuthenticationManager;
import org.springframework.security.core.userdetails.UserDetailsService;
import org.springframework.security.crypto.bcrypt.BCryptPasswordEncoder;
import org.springframework.security.oauth2.config.annotation.configurers.ClientDetailsServiceConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configuration.AuthorizationServerConfigurerAdapter;
import org.springframework.security.oauth2.config.annotation.web.configuration.EnableAuthorizationServer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerEndpointsConfigurer;
import org.springframework.security.oauth2.config.annotation.web.configurers.AuthorizationServerSecurityConfigurer;
import org.springframework.security.oauth2.provider.token.TokenStore;
import org.springframework.security.oauth2.provider.token.store.redis.RedisTokenStore;

import javax.sql.DataSource;

@Configuration
@EnableAuthorizationServer // 这个注解告诉 Spring 这个应用是 OAuth2 的授权服务器//
// 提供/oauth/authorize,/oauth/token,/oauth/check_token,/oauth/confirm_access,/oauth/error
public class AuthorizationServerConfig extends AuthorizationServerConfigurerAdapter {

    @Autowired
    @Qualifier("authenticationManagerBean")
    private AuthenticationManager authenticationManager;

    @Autowired
    private RedisConnectionFactory connectionFactory;

    @Autowired
    private UserDetailsService userDetailsService;


    private final static   String client_id = "client";

    private final static   String client_secret = "admin";

    @Bean
    public TokenStore tokenStore() {
        RedisTokenStore redis = new RedisTokenStore(connectionFactory);
        return redis;
//        return new InMemoryTokenStore(); //使用内存中的 token store
//        return new JdbcTokenStore(dataSource); ///使用Jdbctoken store
    }

    @Override
    public void configure(ClientDetailsServiceConfigurer clients) throws Exception {
        clients.inMemory()
//                密码模式
//                .withClient(client_id)
//                .secret(new BCryptPasswordEncoder().encode(client_secret))
//                // 密码模式
//                .authorizedGrantTypes("password", "refresh_token")//允许授权范围
//                .authorities("ROLE_ADMIN","ROLE_USER")//客户端可以使用的权限
//                .scopes( "read", "write")
//                .redirectUris("http://www.baidu.com")
//                .accessTokenValiditySeconds(7200)
//                .refreshTokenValiditySeconds(7200)

//                授权码
                      .withClient(client_id)
                .secret(new BCryptPasswordEncoder().encode(client_secret))
                .authorizedGrantTypes("authorization_code")
                .scopes("all")
                .authorities("ROLE_ADMIN")
                .redirectUris("http://www.baidu.com")
                .accessTokenValiditySeconds(7200)
                .refreshTokenValiditySeconds(7200);


    }

    @Override
    public void configure(AuthorizationServerEndpointsConfigurer endpoints) throws Exception {
        String urlPrefix = "";
        endpoints.tokenStore(tokenStore())
                .authenticationManager(authenticationManager)
//                将目标的路径 换成自己想要的请求
                .pathMapping("/oauth/authorize", urlPrefix+"/oauth/authorize")
                .pathMapping("/oauth/token", urlPrefix+"/oauth/token")
                .pathMapping("/oauth/confirm_access", urlPrefix+"/oauth/confirm_access")
                .pathMapping("/oauth/error", urlPrefix+"/oauth/error")
                .pathMapping("/oauth/check_token", urlPrefix+"/oauth/check_token")
                .pathMapping("/oauth/token_key", urlPrefix+"/oauth/token_key")
                .userDetailsService(userDetailsService);//必须设置 UserDetailsService 否则刷新token 时会报错
}

    @Override
    public void configure(AuthorizationServerSecurityConfigurer security) throws Exception {
        security
                .tokenKeyAccess("permitAll()")
                .checkTokenAccess("isAuthenticated()")
                .allowFormAuthenticationForClients();//允许表单登录

    }
}
